
const searchbtn = document.querySelector(".search");
const locationinp = document.querySelector(".locationinp");
const card = document.querySelector(".card");


const API_KEY = "3045dd712ffe6e702e3245525ac7fa38"; 
const BASE_URL = "https://api.openweathermap.org/data/2.5";


async function getWeather(cityName) {
    try {
        const response = await fetch(`${BASE_URL}/weather?q=${encodeURIComponent(cityName)}&appid=${API_KEY}&units=metric`);
        
        if (!response.ok) {
            if (response.status === 404) {
                throw new Error("City not found");
            } else {
                throw new Error(`API Error: ${response.status}`);
            }
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error("Error fetching weather data:", error);
        return null;
    }
}


async function getForecast(cityName) {
    try {
        const response = await fetch(`${BASE_URL}/forecast?q=${encodeURIComponent(cityName)}&appid=${API_KEY}&units=metric`);
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error("Error fetching forecast data:", error);
        return null;
    }
}

async function getWeatherData(cityName) {
    showLoadingState();
    
    try {
      
        const [weatherData, forecastData] = await Promise.all([
            getWeather(cityName),
            getForecast(cityName)
        ]);
        
        if (!weatherData) {
            showErrorState("City not found. Please try another location.");
            return;
        }
        
      
        showWeatherInfo(weatherData, forecastData);
    } catch (error) {
        showErrorState("An error occurred. Please try again later.");
        console.error("Error:", error);
    }
}


function showLoadingState() {
    card.innerHTML = `
        <div class="flex flex-col items-center justify-center py-10">
            <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
            <p class="text-gray-400">Loading weather data...</p>
        </div>
    `;
}


function showErrorState(message) {
    card.innerHTML = `
        <div class="text-center py-10">
            <i class="fas fa-exclamation-circle text-red-500 text-4xl mb-4"></i>
            <p class="text-red-400 font-medium">${message}</p>
            <p class="text-gray-400 mt-2 text-sm">Please check the city name and try again.</p>
        </div>
    `;
}

function formatDate(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString('en-US', { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric' 
    });
}


function formatTime(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true
    });
}


function getWeatherIcon(iconCode) {
    const iconMap = {
        '01d': 'fa-sun',          
        '01n': 'fa-moon',          
        '02d': 'fa-cloud-sun',     
        '02n': 'fa-cloud-moon',   
        '03d': 'fa-cloud',         
        '03n': 'fa-cloud',
        '04d': 'fa-cloud',         
        '04n': 'fa-cloud',
        '09d': 'fa-cloud-showers-heavy', 
        '09n': 'fa-cloud-showers-heavy',
        '10d': 'fa-cloud-sun-rain',
        '10n': 'fa-cloud-moon-rain', 
        '11d': 'fa-bolt',        
        '11n': 'fa-bolt',
        '13d': 'fa-snowflake',    
        '13n': 'fa-snowflake',
        '50d': 'fa-smog',          
        '50n': 'fa-smog'
    };
    
    return iconMap[iconCode] || 'fa-cloud';
}


function getWeatherBackground(iconCode) {
    if (iconCode.startsWith('01') || iconCode.startsWith('02')) {
        return 'from-blue-400 to-blue-600'; 
    } else if (iconCode.startsWith('03') || iconCode.startsWith('04')) {
        return 'from-gray-400 to-gray-600';
    } else if (iconCode.startsWith('09') || iconCode.startsWith('10')) {
        return 'from-blue-700 to-blue-900'; 
    } else if (iconCode.startsWith('11')) {
        return 'from-purple-700 to-purple-900'; 
    } else if (iconCode.startsWith('13')) {
        return 'from-blue-200 to-blue-400'; 
    } else {
        return 'from-gray-500 to-gray-700';
    }
}


function showWeatherInfo(weatherData, forecastData) {
    console.log("Weather Data:", weatherData);
    console.log("Forecast Data:", forecastData);
    
   
    const cityName = weatherData.name;
    const country = weatherData.sys.country;
    const temperature = Math.round(weatherData.main.temp);
    const feelsLike = Math.round(weatherData.main.feels_like);
    const description = weatherData.weather[0].description;
    const humidity = weatherData.main.humidity;
    const windSpeed = weatherData.wind.speed;
    const pressure = weatherData.main.pressure;
    const visibility = (weatherData.visibility / 1000).toFixed(1); 
    const sunrise = formatTime(weatherData.sys.sunrise);
    const sunset = formatTime(weatherData.sys.sunset);
    const iconCode = weatherData.weather[0].icon;
    const weatherIcon = getWeatherIcon(iconCode);
    const bgGradient = getWeatherBackground(iconCode);
    
  
    let html = `
        <div class="bg-gradient-to-r ${bgGradient} rounded-t-xl p-6 text-white">
            <div class="flex justify-between items-start">
                <div>
                    <h2 class="text-3xl font-bold">${cityName}, ${country}</h2>
                    <p class="text-white text-opacity-90">${formatDate(weatherData.dt)}</p>
                    <p class="capitalize mt-1 text-white text-opacity-80">${description}</p>
                </div>
                <div class="text-right">
                    <div class="text-5xl font-bold">${temperature}°C</div>
                    <p class="text-white text-opacity-90">Feels like: ${feelsLike}°C</p>
                </div>
            </div>
            <div class="mt-6 flex justify-center">
                <i class="fas ${weatherIcon} text-6xl text-white text-opacity-90"></i>
            </div>
        </div>
        
        <div class="bg-gray-800 p-6 rounded-b-xl">
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                <div class="bg-gray-700 p-3 rounded-lg text-center">
                    <i class="fas fa-tint text-blue-400 mb-2"></i>
                    <p class="text-gray-400 text-xs">Humidity</p>
                    <p class="text-lg font-semibold">${humidity}%</p>
                </div>
                <div class="bg-gray-700 p-3 rounded-lg text-center">
                    <i class="fas fa-wind text-blue-400 mb-2"></i>
                    <p class="text-gray-400 text-xs">Wind</p>
                    <p class="text-lg font-semibold">${windSpeed} m/s</p>
                </div>
                <div class="bg-gray-700 p-3 rounded-lg text-center">
                    <i class="fas fa-compress-alt text-blue-400 mb-2"></i>
                    <p class="text-gray-400 text-xs">Pressure</p>
                    <p class="text-lg font-semibold">${pressure} hPa</p>
                </div>
                <div class="bg-gray-700 p-3 rounded-lg text-center">
                    <i class="fas fa-eye text-blue-400 mb-2"></i>
                    <p class="text-gray-400 text-xs">Visibility</p>
                    <p class="text-lg font-semibold">${visibility} km</p>
                </div>
            </div>
            
            <div class="flex justify-between items-center mb-4 bg-gray-700 rounded-lg p-3">
                <div class="text-center">
                    <i class="fas fa-sun text-yellow-400 mb-1"></i>
                    <p class="text-gray-400 text-xs">Sunrise</p>
                    <p class="text-sm font-medium">${sunrise}</p>
                </div>
                <div class="h-8 border-l border-gray-600"></div>
                <div class="text-center">
                    <i class="fas fa-moon text-blue-300 mb-1"></i>
                    <p class="text-gray-400 text-xs">Sunset</p>
                    <p class="text-sm font-medium">${sunset}</p>
                </div>
            </div>
    `;
    
    
    if (forecastData && forecastData.list) {
       
        const dailyForecasts = [];
        const processedDates = new Set();
        
        for (const forecast of forecastData.list) {
            const date = new Date(forecast.dt * 1000).toDateString();
            
          
            if (processedDates.has(date)) continue;
            
            processedDates.add(date);
            dailyForecasts.push(forecast);
            
          
            if (dailyForecasts.length >= 5) break;
        }
        
       
        html += `
            <div class="mt-4">
                <h3 class="text-white text-lg font-medium mb-3">5-Day Forecast</h3>
                <div class="grid grid-cols-5 gap-2">
        `;
        
       
        for (const forecast of dailyForecasts) {
            const date = formatDate(forecast.dt);
            const temp = Math.round(forecast.main.temp);
            const iconCode = forecast.weather[0].icon;
            const icon = getWeatherIcon(iconCode);
            
            html += `
                <div class="bg-gray-700 rounded-lg p-2 text-center">
                    <p class="text-xs text-gray-400">${date}</p>
                    <i class="fas ${icon} text-blue-400 my-2"></i>
                    <p class="text-sm font-medium">${temp}°C</p>
                </div>
            `;
        }
        
        html += `
                </div>
            </div>
        `;
    }
   
    html += `</div>`;
    
   
    card.innerHTML = html;
}


searchbtn.addEventListener('click', function() {
    const city = locationinp.value.trim();
    
    if (city.length > 0) {
        getWeatherData(city);
    } else {
        alert("Please enter a city name");
    }
});


locationinp.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        searchbtn.click();
    }
});




window.addEventListener('load', () => {
    locationinp.focus();
});